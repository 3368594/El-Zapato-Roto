/*PRODUCTOS*/
INSERT INTO productos (nombre, presentacion, valor) VALUES ('botas', 'seguridad', 1000);
INSERT INTO productos (nombre, presentacion, valor) VALUES ('zapatos deportivos', 'con tacones', 1200);
INSERT INTO productos (nombre, presentacion, valor) VALUES ('zapatos de vestir', 'Punta Redonda', 1800);
/*CLIENTE*/
INSERT INTO clientes (identificacion, nombre, pais) VALUES ('1001', 'Andrew Fuentes', 'Venezuela');
INSERT INTO clientes (identificacion, nombre, pais) VALUES ('1002', 'Jose Daniel', 'Venezuela');
INSERT INTO clientes (identificacion, nombre, pais) VALUES ('1003', 'Christopher Fuentes', 'Ecuador');
/*INVENTARIO*/
INSERT INTO inventario (id_inventario, producto, tipo_movimiento, fecha, cantidad) VALUES (1, 'botas', 'Entrada', '2020-06-01', 20);
INSERT INTO inventario (id_inventario, producto, tipo_movimiento, fecha, cantidad) VALUES (2, 'botas', 'Salida', '2020-06-04', 5);
INSERT INTO inventario (id_inventario, producto, tipo_movimiento, fecha, cantidad) VALUES (3, 'zapatos deportivos', 'Entrada', '2020-06-01', 10);
INSERT INTO inventario (id_inventario, producto, tipo_movimiento, fecha, cantidad) VALUES (4, 'zapatos deportivos', 'Salida', '2020-06-05', 2);
INSERT INTO inventario (id_inventario, producto, tipo_movimiento, fecha, cantidad) VALUES (5, 'zapatos de vestir', 'Entrada', '2020-06-01', 5);
INSERT INTO inventario (id_inventario, producto, tipo_movimiento, fecha, cantidad) VALUES (6, 'zapatos de vestir', 'Salida', '2020-06-07', 1);
INSERT INTO inventario (id_inventario, producto, tipo_movimiento, fecha, cantidad) VALUES (7, 'zapatos de vestir', 'Salida', '2020-06-08', 2);
/*FACTURA*/
INSERT INTO factura (id_factura, cliente, inventario_producto, impuesto, descuento, valor_pagar) VALUES (1, '1001', 2 ,10 , 10, 5000);
INSERT INTO factura (id_factura, cliente, inventario_producto, impuesto, descuento, valor_pagar) VALUES (2, '1002', 4 ,10 , 10, 2400);
INSERT INTO factura (id_factura, cliente, inventario_producto, impuesto, descuento, valor_pagar) VALUES (3, '1003', 6 ,10 , 10, 1800);
INSERT INTO factura (id_factura, cliente, inventario_producto, impuesto, descuento, valor_pagar) VALUES (4, '1001', 7 ,5 , 5, 3600);