/*Asumimos que el nombre del producto es unico*/
CREATE TABLE productos(
	nombre varchar(255) primary key,
	presentacion text,
	valor real
);
/*asumimos que el identificador del cliente es unico*/
CREATE TABLE clientes(
	identificacion varchar(255) primary key,
	nombre varchar(255),
	pais varchar(255)
);
/*añadimos un identificador numerico para poder identificar cada una de las transacciones*/
CREATE TABLE inventario (
	id_inventario integer primary key,
	producto varchar(255), 
	tipo_movimiento varchar(255) CHECK (tipo_movimiento='Entrada' OR tipo_movimiento='Salida'),
	fecha date,
	cantidad integer,
	FOREIGN KEY (producto) REFERENCES productos(nombre)
);
/*ya que se necesita la cantidad de productos y esto se encuentra en la tabla inventario con tipo
de movimiento salida y manejamos cantidad hacemos referencia a esta variable para identificar 
los productos*/
CREATE TABLE factura(
	id_factura integer primary key,
	cliente varchar(255),
	inventario_producto integer,
	impuesto real,
	descuento real,
	valor_pagar real,
	FOREIGN KEY (cliente) REFERENCES clientes(identificacion),
	FOREIGN KEY (inventario_producto) REFERENCES inventario(id_inventario)
);
